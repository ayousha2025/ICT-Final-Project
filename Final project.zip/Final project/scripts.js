document.addEventListener("DOMContentLoaded", () => {
  const path = window.location.pathname.split("/").pop();
  const links = document.querySelectorAll(".nav-links a");
  links.forEach((a) => {
    const href = a.getAttribute("href");
    if (
      href === path ||
      (href === "index.html" && (path === "" || path === "index.html"))
    ) {
      a.classList.add("active");
      a.style.color = "#5C4033"; // active link color
    }
  });
});

function openModal(imgSrc, captionText) {
  const modal = document.getElementById("imgModal");
  const modalImg = document.getElementById("modalImg");
  const caption = document.getElementById("modalCaption");
  if (!modal || !modalImg || !caption) return;

  modal.style.display = "block";      // Show modal
  modalImg.src = imgSrc;              // Set image source
  caption.textContent = captionText;  // Set caption
}

// Close modal function
function closeModal() {
  const modal = document.getElementById("imgModal");
  if (modal) modal.style.display = "none";
}

// Close modal when clicking outside image or clicking ×
document.getElementById("imgModal").addEventListener("click", (e) => {
  if (e.target.id === "imgModal") {
    closeModal();
  }
});
document.querySelector(".close").addEventListener("click", closeModal);

// Close modal with Esc key
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    closeModal();
  }
});
